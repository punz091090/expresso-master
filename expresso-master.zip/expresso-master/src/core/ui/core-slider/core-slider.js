﻿
var CoreNumberBox = require('../core-numberbox/core-numberbox.js');

require('./core-slider.less');

var component = CoreNumberBox.extend({

    template: require('./core-slider.html'),

});

module.exports = component;
